package com.example.crazyadvanced

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import android.Manifest
import android.content.pm.PackageManager

class MainActivity : AppCompatActivity() {

    private lateinit var btnPrepare: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnSuggest: Button
    private lateinit var tvStatus: TextView

    private var resultIntentData: Intent? = null
    private var resultCode: Int = Activity.RESULT_CANCELED

    private val requestPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
            // nothing extra: permission results handled when needed
        }

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK && r.data != null) {
                resultCode = r.resultCode
                resultIntentData = r.data
                tvStatus.text = "إذن الشاشة جاهز — تقدر تبدا التسجيل"
            } else {
                tvStatus.text = "رفض إذن الشاشة"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnPrepare = findViewById(R.id.btnPrepare)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnSuggest = findViewById(R.id.btnSuggest)
        tvStatus = findViewById(R.id.statusText)

        btnPrepare.setOnClickListener {
            // request runtime permissions first
            requestPermissions.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val intent = mgr.createScreenCaptureIntent()
            screenCaptureLauncher.launch(intent)
        }

        btnStart.setOnClickListener {
            if (resultIntentData == null) {
                tvStatus.text = "خصّك أولاً تعطينا إذن تسجيل الشاشة (حضّر الإذن)"
                return@setOnClickListener
            }
            val service = Intent(this, RecorderForegroundService::class.java)
            service.putExtra("resultCode", resultCode)
            service.putExtra("resultData", resultIntentData)
            service.action = RecorderForegroundService.ACTION_START
            ActivityCompat.startForegroundService(this, service)
            tvStatus.text = "الحالة: التسجيل بدا"
        }

        btnStop.setOnClickListener {
            val service = Intent(this, RecorderForegroundService::class.java)
            service.action = RecorderForegroundService.ACTION_STOP
            startService(service)
            tvStatus.text = "الحالة: التسجيل توقف"
        }

        btnSuggest.setOnClickListener {
            // Demo suggestion dialog: in real use hook to Analyzer
            val suggestion = SuggestionEngine.simpleSuggestion()
            AlertDialog.Builder(this)
                .setTitle("اقتراح رهان")
                .setMessage("التوصية: " + suggestion)
                .setPositiveButton("حسنا") { d, _ -> d.dismiss() }
                .show()
        }
    }
}
