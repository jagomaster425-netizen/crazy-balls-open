package com.example.crazyadvanced

import java.util.*

object SuggestionEngine {
    fun simpleSuggestion(): String {
        // dummy simple heuristic: random
        val r = Random()
        val picks = (1..60).shuffled().take(3)
        return picks.joinToString(", ")
    }
}
