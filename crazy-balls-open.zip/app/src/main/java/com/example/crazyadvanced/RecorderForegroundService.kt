package com.example.crazyadvanced

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.util.Log
import android.view.Surface
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RecorderForegroundService : Service() {
    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        private const val CHANNEL_ID = "crazy_rec_channel"
    }

    private var mediaProjection: MediaProjection? = null
    private var mediaRecorder: MediaRecorder? = null
    private var virtualDisplaySurface: Surface? = null
    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when(action) {
            ACTION_START -> {
                val rc = intent.getIntExtra("resultCode", -1)
                val data = intent.getParcelableExtra<Intent>("resultData")
                startForeground(101, buildNotification("التسجيل جارٍ"))
                startRecording(rc, data)
            }
            ACTION_STOP -> {
                stopRecording()
                stopForeground(true)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Crazy recorder", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(content: String): Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Crazy Recorder")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
        return builder.build()
    }

    private fun startRecording(resultCode: Int, data: Intent?) {
        if (data == null) {
            Log.e("RFS", "no projection data")
            return
        }
        try {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mgr.getMediaProjection(resultCode, data)
            setupMediaRecorder()
            val surface = mediaRecorder!!.surface
            // create virtual display and attach surface
            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi
            mediaProjection!!.createVirtualDisplay("rec-display", width, height, density, 0, surface, null, null)
            mediaRecorder!!.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupMediaRecorder() {
        try {
            mediaRecorder = MediaRecorder()
            mediaRecorder?.setAudioSource(MediaRecorder.AudioSource.MIC)
            mediaRecorder?.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mediaRecorder?.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            val outFile = createOutputFile()
            mediaRecorder?.setOutputFile(outFile.absolutePath)
            mediaRecorder?.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            mediaRecorder?.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            val metrics = resources.displayMetrics
            mediaRecorder?.setVideoSize(metrics.widthPixels, metrics.heightPixels)
            mediaRecorder?.setVideoFrameRate(30)
            mediaRecorder?.setVideoEncodingBitRate(4_000_000)
            mediaRecorder?.prepare()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopRecording() {
        try {
            mediaRecorder?.stop()
            mediaRecorder?.reset()
            mediaProjection?.stop()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            mediaRecorder?.release()
            mediaRecorder = null
            mediaProjection = null
        }
    }

    private fun createOutputFile(): File {
        val folder = File(getExternalFilesDir(null), "crazy_records")
        if (!folder.exists()) folder.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return File(folder, "rec_$stamp.mp4")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
